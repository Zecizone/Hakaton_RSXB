import { useContext } from 'react';
import { valueNameContext } from '../../Context';
import styles from './Input.module.scss';

const Input = ({ placeholder }) => {
	let { valueName, setValueName } = useContext(valueNameContext);

	return (
		<div>
			<input
				className={styles.input}
				type='text'
				placeholder={placeholder}
				value={valueName}
				onChange={event => setValueName(event.target.value)}
			/>
		</div>
	);
};

export default Input;
