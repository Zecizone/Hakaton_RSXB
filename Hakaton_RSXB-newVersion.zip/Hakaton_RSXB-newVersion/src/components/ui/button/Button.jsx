import { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { valueNameContext } from '../../Context';
import styles from './Button.module.scss';

const Button = ({ textButton, begin, exit, help }) => {
	const navigate = useNavigate();
	let { valueName, setValueName } = useContext(valueNameContext);

	return (
		<>
			{exit || help ? (
				<button
					className={exit ? styles.exit : styles.help}
					style={{ backgroundImage: exit ? exit : help }}
				>
					{/* <img src={exit ? exit : help} alt='image' /> */}
				</button>
			) : (
				<button
					className={styles.intro_button}
					onClick={() => {
						begin ? navigate('/stepOne') : <></>;
						localStorage.setItem('valueName', valueName);
					}}
				>
					{textButton ? textButton : 'Продолжить'}
				</button>
			)}
		</>
	);
};

export default Button;
