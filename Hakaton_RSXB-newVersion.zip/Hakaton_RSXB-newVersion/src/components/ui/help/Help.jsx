import styles from '../help/Help.module.scss';

const Help = ({ setViewHelp }) => {
	return (
		<div
			id='openModal'
			onClick={() => setViewHelp(false)}
			className={styles.modal}
		>
			<div className={styles.modal_dialog}>
				<div className={styles.modal_content}>
					<div className={styles.modal_header}>
						<a href='#close' className={styles.close}>
							×
						</a>
					</div>
					<div className={styles.modal_body}>
						<p className={styles.modal_text}>
							<span>Наша визуальная новелла</span> - это интерактивная игра,
							включающая анимацию с текстом, которую читает игрок. <br />
							Игрок имеет возможность выбирать различные варианты действий, что
							влияет на развитие сюжета.
						</p>
						<p className={styles.modal_title}>Как сохранить/загрузить игру?</p>
						<p className={styles.modal_text}>
							Игрок имеет возможность выбирать различные варианты действий, что
							влияет на развитие сюжета.
						</p>
						<p className={styles.modal_title}>Как пропустить диалог?</p>
						<p className={styles.modal_text}>
							Вы можете пропустить диалог, нажимаю в любое место экрана во время
							диалога.
						</p>
						<p className={styles.modal_title}>
							Как влияют мои выборы на историю?
						</p>
						<p className={styles.modal_text}>
							Ваши выборы влияют на отношения с другими персонажами и на исход
							истории. Они могут привести к различным концовкам.
						</p>
						<p className={styles.teh_pod}>
							Если у вас возникли технические вопросы или проблемы с игрой,
							обратитесь в нашу службу поддержки по адресу <br />
							<strong>support@fermafuturegame.com</strong>. <br /> Мы
							постараемся как можно скорее вам помочь. Мы надеемся, что вам
							понравится наша визуальная новелла <br />
							<strong>«Ферма будущего»</strong>. Удачи в игре!
						</p>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Help;
