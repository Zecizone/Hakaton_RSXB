import { useState } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import data from '../data';
import {
	chapterContext,
	colorStateContext,
	numContext,
	startContext,
	textStepContext,
	valueNameContext,
} from './Context';
import Home from './screens/home/Home';
import Intro from './screens/intro/Intro';
import S5_StepOne from './screens/scene-five/step-one/S5_StepOne';
import S5_StepOne_1 from './screens/scene-five/step-one_1/S5_StepOne_1';
import S5_StepTwo_1 from './screens/scene-five/step-two-1/S5_StepTwo_1';
import S5_StepTwo_2_2 from './screens/scene-five/step-two-2-2/S5_StepTwo_2_2';
import S5_StepTwo_2 from './screens/scene-five/step-two-2/S5_StepTwo_2';
import S5_StepTwo_3_3 from './screens/scene-five/step-two-3-3/S5_StepTwo_3_3';
import S5_StepTwo_3 from './screens/scene-five/step-two-3/S5_StepTwo_3';
import S5_StepTwo from './screens/scene-five/step-two/S5_StepTwo';
import S4_StepOne from './screens/scene-four/step-one/S4_StepOne';
import S4_StepOne_1 from './screens/scene-four/step-one_1/S4_StepOne_1';
import S4_StepTwo_1 from './screens/scene-four/step-two-1/S4_StepTwo_1';
import S4_StepTwo_2_2 from './screens/scene-four/step-two-2-2/S4_StepTwo_2_2';
import S4_StepTwo_2 from './screens/scene-four/step-two-2/S4_StepTwo_2';
import S4_StepTwo_3_3 from './screens/scene-four/step-two-3-3/S4_StepTwo_3_3';
import S4_StepTwo_3 from './screens/scene-four/step-two-3/S4_StepTwo_3';
import S4_StepTwo from './screens/scene-four/step-two/S4_StepTwo';
import StepOne from './screens/scene-one/step-one/StepOne';
import StepOne_1 from './screens/scene-one/step-one_1/StepOne_1';
import StepTwo_2_2 from './screens/scene-one/step-two-2-2/StepTwo_2_2';
import StepTwo_2 from './screens/scene-one/step-two-2/StepTwo_2';
import StepTwo_3_3 from './screens/scene-one/step-two-3-3/StepTwo_3_3';
import StepTwo_3 from './screens/scene-one/step-two-3/StepTwo_3';
import StepTwo from './screens/scene-one/step-two/StepTwo';
import S3_StepOne from './screens/scene-three/step-one/S3_StepOne';
import S3_StepOne_1 from './screens/scene-three/step-one_1/S3_StepOne_1';
import S3_StepTwo_1 from './screens/scene-three/step-two-1/S3_StepTwo_1';
import S3_StepTwo_2_2 from './screens/scene-three/step-two-2-2/S3_StepTwo_2_2';
import S3_StepTwo_2 from './screens/scene-three/step-two-2/S3_StepTwo_2';
import S3_StepTwo_3_3 from './screens/scene-three/step-two-3-3/S3_StepTwo_3_3';
import S3_StepTwo_3 from './screens/scene-three/step-two-3/S3_StepTwo_3';
import S3_StepTwo from './screens/scene-three/step-two/S3_StepTwo';
import S2_StepOne from './screens/scene-two/step-one/S2_StepOne';
import S2_StepOne_1 from './screens/scene-two/step-one_1/S2_StepOne_1';
import S2_StepTwo_1 from './screens/scene-two/step-two-1/S2_StepTwo_1';
import S2_StepTwo_2_2 from './screens/scene-two/step-two-2-2/S2_StepTwo_2_2';
import S2_StepTwo_2 from './screens/scene-two/step-two-2/S2_StepTwo_2';
import S2_StepTwo_3_3 from './screens/scene-two/step-two-3-3/S2_StepTwo_3_3';
import S2_StepTwo_3 from './screens/scene-two/step-two-3/S2_StepTwo_3';
import S2_StepTwo from './screens/scene-two/step-two/S2_StepTwo';

const Router = () => {
	let [num, setNum] = useState(2);
	let [colorState, setColorState] = useState('2');
	let [chapter, setChapter] = useState(0);
	let [textStep, setTextStep] = useState(data[chapter][`choice${num}`].text);
	let [valueName, setValueName] = useState('');
	let [start, setStart] = useState(true);

	return (
		<startContext.Provider value={{ start, setStart }}>
			<valueNameContext.Provider value={{ valueName, setValueName }}>
				<textStepContext.Provider value={{ textStep, setTextStep }}>
					<chapterContext.Provider value={{ chapter, setChapter }}>
						<colorStateContext.Provider value={{ colorState, setColorState }}>
							<numContext.Provider value={{ num, setNum }}>
								<BrowserRouter>
									<Routes>
										<Route element={<Home />} path='/' />
										<Route element={<Intro />} path='/intro' />
										<Route element={<StepOne />} path='/stepOne' />
										<Route element={<StepOne_1 />} path='/stepOne/stepOne_1' />
										<Route
											element={<StepTwo />}
											path='/stepOne/stepOne_1/stepTwo'
										/>
										<Route
											element={<StepTwo_2 />}
											path='/stepOne/stepOne_1/stepTwo_2'
										/>
										<Route
											element={<StepTwo_2_2 />}
											path='/stepOne/stepOne_1/stepTwo_2/stepTwo_2_2'
										/>
										<Route
											element={<StepTwo_3 />}
											path='/stepOne/stepOne_1/stepTwo_3'
										/>
										<Route
											element={<StepTwo_3_3 />}
											path='/stepOne/stepOne_1/stepTwo_3/stepOne_3_3'
										/>
										<Route element={<S2_StepOne />} path='/S2_StepOne' />
										<Route
											element={<S2_StepOne_1 />}
											path='/S2_StepOne/S2_StepOne_1'
										/>
										<Route
											element={<S2_StepTwo />}
											path='/S2_StepOne/S2_StepOne_1/S2_StepTwo'
										/>
										<Route
											element={<S2_StepTwo_2 />}
											path='/S2_StepOne/S2_StepOne_1/S2_StepTwo_2'
										/>
										<Route
											element={<S2_StepTwo_1 />}
											path='/S2_StepOne/S2_StepOne_1/S2_StepTwo/S2_StepTwo_1'
										/>
										<Route
											element={<S2_StepTwo_2_2 />}
											path='/S2_StepOne/S2_StepOne_1/S2_StepTwo_2/S2_StepTwo_2_2'
										/>
										<Route
											element={<S2_StepTwo_3 />}
											path='/S2_StepOne/S2_StepOne_1/S2_StepTwo_3'
										/>
										<Route
											element={<S2_StepTwo_3_3 />}
											path='/S2_StepOne/S2_StepOne_1/S2_StepTwo_3/S2_StepTwo_3_3'
										/>
										<Route element={<S3_StepOne />} path='/S3_StepOne' />
										<Route
											element={<S3_StepOne_1 />}
											path='/S3_StepOne/S3_StepOne_1'
										/>
										<Route
											element={<S3_StepTwo />}
											path='/S3_StepOne/S3_StepOne_1/S3_StepTwo'
										/>
										<Route
											element={<S3_StepTwo_1 />}
											path='/S3_StepOne/S3_StepOne_1/S3_StepTwo/S3_StepTwo_1'
										/>
										<Route
											element={<S3_StepTwo_2 />}
											path='/S3_StepOne/S3_StepOne_1/S3_StepTwo_2'
										/>
										<Route
											element={<S3_StepTwo_2_2 />}
											path='/S3_StepOne/S3_StepOne_1/S3_StepTwo_2/S3_StepTwo_2_2'
										/>
										<Route
											element={<S3_StepTwo_3 />}
											path='/S3_StepOne/S3_StepOne_1/S3_StepTwo_3'
										/>
										<Route
											element={<S3_StepTwo_3_3 />}
											path='/S3_StepOne/S3_StepOne_1/S3_StepTwo_3/S3_StepTwo_3_3'
										/>
										<Route element={<S4_StepOne />} path='/S4_StepOne' />
										<Route
											element={<S4_StepOne_1 />}
											path='/S4_StepOne/S4_StepOne_1'
										/>
										<Route
											element={<S4_StepTwo />}
											path='/S4_StepOne/S4_StepOne_1/S4_StepTwo'
										/>
										<Route
											element={<S4_StepTwo_1 />}
											path='/S4_StepOne/S4_StepOne_1/S4_StepTwo/S4_StepTwo_1'
										/>
										<Route
											element={<S4_StepTwo_2 />}
											path='/S4_StepOne/S4_StepOne_1/S4_StepTwo_2'
										/>
										<Route
											element={<S4_StepTwo_2_2 />}
											path='/S4_StepOne/S4_StepOne_1/S4_StepTwo_2/S4_StepTwo_2_2'
										/>
										<Route
											element={<S4_StepTwo_3 />}
											path='/S4_StepOne/S4_StepOne_1/S4_StepTwo_3'
										/>
										<Route
											element={<S4_StepTwo_3_3 />}
											path='/S4_StepOne/S4_StepOne_1/S4_StepTwo_3/S4_StepTwo_3_3'
										/>
										<Route element={<S5_StepOne />} path='/S5_StepOne' />
										<Route
											element={<S5_StepOne_1 />}
											path='/S5_StepOne/S5_StepOne_1'
										/>
										<Route
											element={<S5_StepTwo />}
											path='/S5_StepOne/S5_StepOne_1/S5_StepTwo'
										/>
										<Route
											element={<S5_StepTwo_1 />}
											path='/S5_StepOne/S5_StepOne_1/S5_StepTwo/S5_StepTwo_1'
										/>
										<Route
											element={<S5_StepTwo_2 />}
											path='/S5_StepOne/S5_StepOne_1/S5_StepTwo_2'
										/>
										<Route
											element={<S5_StepTwo_2_2 />}
											path='/S5_StepOne/S5_StepOne_1/S5_StepTwo_2/S5_StepTwo_2_2'
										/>
										<Route
											element={<S5_StepTwo_3 />}
											path='/S5_StepOne/S5_StepOne_1/S5_StepTwo_3'
										/>
										<Route
											element={<S5_StepTwo_3_3 />}
											path='/S5_StepOne/S5_StepOne_1/S5_StepTwo_3/S5_StepTwo_3_3'
										/>
									</Routes>
								</BrowserRouter>
							</numContext.Provider>
						</colorStateContext.Provider>
					</chapterContext.Provider>
				</textStepContext.Provider>
			</valueNameContext.Provider>
		</startContext.Provider>
	);
};

export default Router;
