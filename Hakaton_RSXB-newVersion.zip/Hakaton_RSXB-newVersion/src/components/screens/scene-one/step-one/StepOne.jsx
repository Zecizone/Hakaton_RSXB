import { useState } from 'react';
import { Link } from 'react-router-dom';
import data from '../../../../data';
import styles from './StepOne.module.scss';

const StepOne = () => {
	const [text, setText] = useState('');
	let requestFunk = async () => {
		fetch('https://farm.pythonanywhere.com/scenes?format=json')
			.then(response => response.json())
			.then(response => setText(response.intro_step.intro_step[0].introStep));
	};
	requestFunk();

	return (
		<div
			className={styles.stepOne}
			style={{ backgroundImage: data[0].choice1.color }}
		>
			{/* <div>
				<Button exit={'../public/exit-no-active.svg'} />
				<Button help={'../public/help-no-active.svg'} />
			</div> */}
			<Link to={'./stepOne_1'}>
				<div className={styles.text__scena}>
					{/* <p>{data[5].introStep}</p> */}
					<p>{text}</p>
				</div>
			</Link>
		</div>
	);
};

export default StepOne;
