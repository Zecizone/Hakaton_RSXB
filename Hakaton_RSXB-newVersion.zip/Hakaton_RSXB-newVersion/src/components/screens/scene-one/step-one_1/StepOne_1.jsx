import { Link } from 'react-router-dom';
import data from '../../../../data';
import styles from './StepOne_1.module.scss';

const StepOne = () => {
	console.log(data[0].choice1.color);
	return (
		<div
			className={styles.stepOne_1}
			style={{ backgroundImage: 'url(../public/scen_1.png)' }}
		>
			<div className={styles.title__menu1}>
				<Link to={'./stepTwo'}>{data[0].choice1.text}</Link>
				<Link to={'./stepTwo_2'}>{data[0].choice2.text}</Link>
				<Link to={'./stepTwo_3'}>{data[0].choice3.text}</Link>
			</div>
		</div>
	);
};

export default StepOne;
