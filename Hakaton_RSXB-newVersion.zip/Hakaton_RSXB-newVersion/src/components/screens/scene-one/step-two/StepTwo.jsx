import { Link } from 'react-router-dom';
import data from '../../../../data';
import styles from './StepTwo.module.scss';

const StepTwo = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../public/scen_1.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S2_StepOne'}>
				<div className={styles.text__scena}>
					<p>{data[0].choice1.consequence}</p>
				</div>
			</Link>
		</div>
	);
};

export default StepTwo;
