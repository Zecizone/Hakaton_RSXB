import { Link } from 'react-router-dom';
import data from '../../../../data';
import styles from './StepTwo_2.module.scss';

const StepTwo_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../public/scen_1.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./stepTwo_2_2'}>
				<div className={styles.text__scena}>
					<p>{data[0].choice2.consequence[0]}</p>
				</div>
			</Link>
		</div>
	);
};

export default StepTwo_2;
