import { Link } from 'react-router-dom';
import styles from './S2_StepTwo_1.module.scss';

const S2_StepTwo_1 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_2-zas.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S3_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						Это была простая, но питательная еда, идеально подходящая для
						тяжелого дня на ферме. Довольные, Вы принялись за еду, наслаждаясь
						каждым куском.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S2_StepTwo_1;
