import { Link } from 'react-router-dom';
import data from '../../../../data';
import styles from './S2_StepOne_1.module.scss';

const S2_StepOne = () => {
	console.log(data[0].choice1.color);
	return (
		<div
			className={styles.stepOne_1}
			style={{ backgroundImage: 'url(../../../../public/scena_2-zas.png)' }}
		>
			{/* <div>
				<Button />
				<Button />
			</div> */}
			<div className={styles.title__menu1}>
				<Link to={'./S2_StepTwo'}>
					Поблагодарить робота и приступить к еде.
				</Link>
				<Link to={'./S2_StepTwo_2'}>
					Проверить, что робот приготовил на завтрак.
				</Link>
				<Link to={'./S2_StepTwo_3'}>
					Направиться в сарай к машинам, пропустив завтрак.
				</Link>
			</div>
		</div>
	);
};

export default S2_StepOne;
