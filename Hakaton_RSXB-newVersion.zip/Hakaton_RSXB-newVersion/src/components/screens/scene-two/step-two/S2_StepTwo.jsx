import { Link } from 'react-router-dom';
import styles from './S2_StepTwo.module.scss';

const S2_StepTwo = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_2-zas.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S2_StepTwo_1'}>
				<div className={styles.text__scena}>
					<p>
						Вы улыбнулись роботу, кивнув головой и произнеся: “Спасибо”. Затем
						вы снова уделили внимание своему завтраку, который был так аппетитно
						подан.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S2_StepTwo;
