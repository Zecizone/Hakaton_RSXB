import { Link } from 'react-router-dom';
import styles from './S2_StepTwo_2.module.scss';

const S2_StepTwo_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_2-zas.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S2_StepTwo_2_2'}>
				<div className={styles.text__scena}>
					<p>
						Прежде чем приступить к завтраку, Вы решили проверить, что робот
						приготовил на завтрак. Он обычно делает все идеально, но Вам всегда
						интересно узнать, какие блюда он выбрал сегодня.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S2_StepTwo_2;
