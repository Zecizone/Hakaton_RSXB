import { Link } from 'react-router-dom';
import styles from './S2_StepTwo_3_3.module.scss';

const S2_StepTwo_3_3 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_2-vyb3.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S3_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						Постепенно Вы поднялись из-за стола и направились быстро к сараю,где
						стояли Ваши машины. Был важен каждый момент тишины перед началом
						длительного рабочего дня.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S2_StepTwo_3_3;
