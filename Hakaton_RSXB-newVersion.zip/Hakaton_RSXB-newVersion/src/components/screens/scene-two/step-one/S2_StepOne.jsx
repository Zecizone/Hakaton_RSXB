import { Link } from 'react-router-dom';
import styles from './S2_StepOne.module.scss';

const S2_StepOne = () => {
	return (
		<div
			className={styles.stepOne}
			style={{ backgroundImage: 'url(../../../../public/scena_2-zas.png)' }}
		>
			{/* <div>
				<Button />
				<Button />
			</div> */}
			<Link to={'./S2_StepOne_1'}>
				<div className={styles.text__scena}>
					<p>
						Вы подходите к кухонному столу, на котором уже накрыт простой, но
						сытный завтрак, приготовленный роботом-помощником.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S2_StepOne;
