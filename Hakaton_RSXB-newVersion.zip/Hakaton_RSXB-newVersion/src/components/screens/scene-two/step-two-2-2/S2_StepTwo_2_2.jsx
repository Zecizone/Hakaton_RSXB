import { Link } from 'react-router-dom';
import styles from './S2_StepTwo_2_2.module.scss';

const S2_StepTwo_2_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_2-zas.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S3_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						Вы заглянули в тарелку и увидели, что робот приготовил свежие яйца,
						бекон и авокадо. От одного вида уже становится вкусно, и Вы с
						нетерпением ждете начала трапезы.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S2_StepTwo_2_2;
