import { useContext, useState } from 'react';
import data from '../../../data';
import { TextIntroContext, colorStateContext } from '../../Context';
import Button from '../../ui/button/Button';
import Input from '../../ui/input/Input';
import styles from './NarrativeWindow.module.scss';

const NarrativeWindow = ({ textButton }) => {
	const [inputName, setInputName] = useState(false);
	let { textIntro, setTextIntro } = useContext(TextIntroContext);
	let { colorState, setColorState } = useContext(colorStateContext);

	const veiwIntro = () => {
		setInputName(true);
	};

	const playIntro = () => {
		if (
			textIntro ===
			'В этом приключении вы окажетесь в коже фермера, который стремится преуспеть в своем деле, все время сталкиваясь с различными проблемами и предлагая решения.'
		) {
			setTextIntro(
				'От вашего выбора зависит будущее вашей фермы и ваших отношений с окружающим миром.'
			);
			setColorState(data[data.length - 1].intro2);
		} else if (
			textIntro ===
			'От вашего выбора зависит будущее вашей фермы и ваших отношений с окружающим миром.'
		) {
			setTextIntro(
				'Помните, что нет правильного или неправильного пути - это ваша история, и вы выбираете, как именно вы будете ее рассказывать.'
			);
			setColorState(data[data.length - 1].intro13);
		} else if (
			textIntro ===
			'Помните, что нет правильного или неправильного пути - это ваша история, и вы выбираете, как именно вы будете ее рассказывать.'
		) {
			veiwIntro();
			setColorState('url(./glav-none.png)');
		}
	};

	const contentDisplay = () => {
		return (
			<>
				{inputName ? (
					<div className={styles.wrapper_input}>
						<h2>Введите свое имя</h2>
						<Input placeholder={'Великий кукурузник'} />
						<Button begin={'begin'} textButton={'Начать приключение'} />
					</div>
				) : (
					<>
						{colorState === data[data.length - 1].intro2 ? (
							<p
								className={styles.text2}
								onClick={() => {
									playIntro();
								}}
							>
								{textButton ? textButton : textIntro}
							</p>
						) : (
							<p
								className={styles.text}
								onClick={() => {
									playIntro();
									// setColorState(data[chapter][`choice${num}`].color);
								}}
							>
								{textButton ? textButton : textIntro}
							</p>
						)}
					</>
				)}
			</>
		);
	};

	return <div>{contentDisplay()}</div>;
};

export default NarrativeWindow;
