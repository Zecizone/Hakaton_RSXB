import { useContext, useState } from 'react';
import data from '../../../data';
import { TextIntroContext, colorStateContext } from '../../Context';
import NarrativeWindow from '../../screens/narrative-window/NarrativeWindow';
import styles from './Intro.module.scss';

const Intro = () => {
	const [textIntro, setTextIntro] = useState(
		'В этом приключении вы окажетесь в коже фермера, который стремится преуспеть в своем деле, все время сталкиваясь с различными проблемами и предлагая решения.'
	);
	let { colorState, setColorState } = useContext(colorStateContext);

	return (
		<>
			{colorState === '2' ? (
				<div
					className={styles.intro}
					style={{ backgroundImage: data[data.length - 1].intro13 }}
				>
					<TextIntroContext.Provider value={{ textIntro, setTextIntro }}>
						<NarrativeWindow />
					</TextIntroContext.Provider>{' '}
				</div>
			) : (
				<div className={styles.intro} style={{ backgroundImage: colorState }}>
					<TextIntroContext.Provider value={{ textIntro, setTextIntro }}>
						<NarrativeWindow />
					</TextIntroContext.Provider>
				</div>
			)}
		</>
	);
};

export default Intro;
