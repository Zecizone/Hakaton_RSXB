import { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { valueNameContext } from '../../Context';
import Help from '../../ui/help/Help';
import styles from './Home.module.scss';

const Home = () => {
	const [showName, setShowName] = useState(false);
	const navigate = useNavigate();
	let { valueName, setValueName } = useContext(valueNameContext);
	const [viewHelp, setViewHelp] = useState(false);

	return (
		<div className={styles.home}>
			{viewHelp ? <Help setViewHelp={setViewHelp} /> : <></>}

			<h1>Ферма будущего</h1>
			<h5>визуальная новелла</h5>
			<ul>
				<li
					onClick={() => {
						setShowName(true);
						navigate('/intro');
					}}
				>
					Новая игра
				</li>
				{valueName ? (
					<Link to={'/stepOne'}>
						<li>Продолжить</li>
					</Link>
				) : (
					<></>
				)}
				<li
					onClick={() => {
						setViewHelp(true);
					}}
				>
					Помощь
				</li>
				<li>Выход</li>
			</ul>
		</div>
	);
};

export default Home;
