import { Link } from 'react-router-dom';
import styles from './S4_StepOne.module.scss';

const S4_StepOne = () => {
	return (
		<div
			className={styles.stepOne}
			style={{ backgroundImage: 'url(../../../../public/glav-none.png)' }}
		>
			{/* <div>
				<Button exit={'../public/exit-no-active.svg'} />
				<Button help={'../public/help-no-active.svg'} />
			</div> */}
			<Link to={'./S4_StepOne_1'}>
				<div className={styles.text__scena}>
					<p>
						Вы решаете разобраться с новым ИТ оборудованием, которое поможет
						автоматизировать работу на ферме и упростит задачи для роботов и для
						Вас.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S4_StepOne;
