import { Link } from 'react-router-dom';
import styles from './S4_StepOne_1.module.scss';

const S4_StepOne_1 = () => {
	console.log(2);
	return (
		<div
			className={styles.stepOne_1}
			style={{ backgroundImage: 'url(../../../../public/glav-none.png)' }}
		>
			{/* <div>
				<Button />
				<Button />
			</div> */}
			<div className={styles.title__menu1}>
				<Link to={'./S4_StepTwo'}>
					Начать установку и настройку оборудования.
				</Link>
				<Link to={'./S4_StepTwo_2'}>Взять день отдыха и ничего не делать.</Link>
				<Link to={'./S4_StepTwo_3'}>
					Рассмотреть ферму и обдумать план по ее модернизации.
				</Link>
			</div>
		</div>
	);
};

export default S4_StepOne_1;
