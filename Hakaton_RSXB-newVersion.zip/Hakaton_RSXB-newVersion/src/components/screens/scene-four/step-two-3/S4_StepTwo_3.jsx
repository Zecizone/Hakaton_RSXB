import { Link } from 'react-router-dom';
import styles from './S4_StepTwo_3.module.scss';

const S4_StepTwo_3 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/glav-none.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S4_StepTwo_3_3'}>
				<div className={styles.text__scena}>
					<p>
						Пройдясь по ферме и вдохнув свежий, чистый воздух, Вы начали
						внимательно рассматривать Ваш участок. У Вас было множество идей по
						дальнейшей модернизации и оптимизации работы: от установки новых
						автоматизированных систем до внедрения более эффективных методов
						обработки почвы.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S4_StepTwo_3;
