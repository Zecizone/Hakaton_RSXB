import { Link } from 'react-router-dom';
import styles from './S4_StepTwo_3_3.module.scss';

const S4_StepTwo_3_3 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/glav-none.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S5_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						Размышляя о новых возможностях, которые открывались перед Вами, Вы
						почувствовали возрастающий энтузиазм и нестерпимое желание воплотить
						Ваши идеи в реальность.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S4_StepTwo_3_3;
