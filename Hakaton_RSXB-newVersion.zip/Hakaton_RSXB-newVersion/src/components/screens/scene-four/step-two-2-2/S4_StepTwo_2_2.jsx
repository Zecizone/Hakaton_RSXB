import { Link } from 'react-router-dom';
import styles from './S4_StepTwo_2_2.module.scss';

const S4_StepTwo_2_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/glav-none.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S5_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						поставили роботов на автономный режим работы и провели весь день
						отдыхая и не делая вообще ничего. Вы просто наблюдали за небом,
						читали книги и наслаждались спокойствием. Это был действительно
						замечательный день, полный редкого для Вас, но жизненно важного
						отдыха.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S4_StepTwo_2_2;
