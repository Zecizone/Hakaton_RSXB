import { Link } from 'react-router-dom';
import styles from './S4_StepTwo_2.module.scss';

const S4_StepTwo_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/glav-none.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S4_StepTwo_2_2'}>
				<div className={styles.text__scena}>
					<p>
						Между всеми этими делами на ферме, Вы решили сделать что-то
						невероятное - устроить себе день отдыха. Вы редко позволяете себе
						такую роскошь, но тогда Вы почувствовали, что действительно
						нуждаетесь в ней. Так что Вы просто отложили все свои дела,
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S4_StepTwo_2;
