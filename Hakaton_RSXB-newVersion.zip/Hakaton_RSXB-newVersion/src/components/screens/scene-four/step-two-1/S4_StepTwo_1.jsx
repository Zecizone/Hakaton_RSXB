import { Link } from 'react-router-dom';
import styles from './S4_StepTwo_1.module.scss';

const S4_StepTwo_1 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_4-vyb3.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S5_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						Вы порой обожаете этот процесс, хотя и требующий внимания, потому
						что знаете, что каждое новшество на Вашей ферме - это шаг вперед,
						это прогресс, который помогает Вам стать еще лучше.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S4_StepTwo_1;
