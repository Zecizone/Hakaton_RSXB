import { Link } from 'react-router-dom';
import styles from './S4_StepTwo.module.scss';

const S4_StepTwo = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_4-vyb3.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S4_StepTwo_1'}>
				<div className={styles.text__scena}>
					<p>
						Окончив работу на поле, Вы переключились на другие важные дела на
						ферме. Первым делом Вы решили начать устанавливать и настраивать
						новое оборудование. Вы тщательно прочитали инструкцию и
						последовательно выполняли каждый шаг, чтобы убедиться, что все
						установлено и настроено правильно.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S4_StepTwo;
