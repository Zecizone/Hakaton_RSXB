import { Link } from 'react-router-dom';
import styles from './S3_StepOne.module.scss';

const S3_StepOne = () => {
	return (
		<div
			className={styles.stepOne}
			style={{ backgroundImage: 'url(../../../../public/scena_3-zas.png)' }}
		>
			{/* <div>
				<Button />
				<Button />
			</div> */}
			<Link to={'./S3_StepOne_1'}>
				<div className={styles.text__scena}>
					<p>
						Вы выходите на поле и видите перед собой трех роботов, готовых к
						работе. Они копают, сеют и поливают поля. Вам нужно решить, какую
						работу сегодня делать.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S3_StepOne;
