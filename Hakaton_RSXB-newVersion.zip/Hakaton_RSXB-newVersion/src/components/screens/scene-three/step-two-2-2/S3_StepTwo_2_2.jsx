import { Link } from 'react-router-dom';
import styles from './S3_StepTwo_2_2.module.scss';

const S3_StepTwo_2_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_3-ambar-2.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S4_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						Роботы, являясь почти продолжением Вашего тела, аккуратно выполняли
						свою работу, показывая замечательные результаты. И вот, после
						нескольких часов тяжелого труда, вы заметили, что новый урожай был
						успешно посажен и готов к росту.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S3_StepTwo_2_2;
