import { Link } from 'react-router-dom';
import styles from './S3_StepTwo_3_3.module.scss';

const S3_StepTwo_3_3 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_3-ambar-2.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S4_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						Затем Вы разработали новый алгоритм, который оптимизировал их
						работу, делая ее более эффективной. После такой подготовки роботы
						были готовы работать с максимальной производительностью, что
						позволило Вам сэкономить время и силы на поле.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S3_StepTwo_3_3;
