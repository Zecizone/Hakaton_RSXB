import { Link } from 'react-router-dom';
import data from '../../../../data';
import styles from './S3_StepOne_1.module.scss';

const S3_StepOne = () => {
	console.log(data[0].choice1.color);
	return (
		<div
			className={styles.stepOne_1}
			style={{ backgroundImage: 'url(../../../../public/scena_3-zas.png)' }}
		>
			{/* <div>
				<Button />
				<Button />
			</div> */}
			<div className={styles.title__menu1}>
				<Link to={'./S3_StepTwo'}>
					Провести обслуживание и диагностику роботов.
				</Link>
				<Link to={'./S3_StepTwo_2'}>
					Помочь роботам и посадить новый урожай.
				</Link>
				<Link to={'./S3_StepTwo_3'}>
					Сперва заняться другими делами (упростить работу роботов с помощью
					ИТ).
				</Link>
			</div>
		</div>
	);
};

export default S3_StepOne;
