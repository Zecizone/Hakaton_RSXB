import { Link } from 'react-router-dom';
import styles from './S3_StepTwo_1.module.scss';

const S3_StepTwo_1 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_3-zas.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S4_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						услышав знакомый гул моторов и увидев ясные данные на дисплее, Вы
						удовлетворенно кивнули. Все было в порядке, и Вы готовы приступить к
						работе.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S3_StepTwo_1;
