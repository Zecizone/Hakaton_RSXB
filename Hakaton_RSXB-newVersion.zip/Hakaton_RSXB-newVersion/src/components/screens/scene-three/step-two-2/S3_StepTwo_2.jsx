import { Link } from 'react-router-dom';
import styles from './S3_StepTwo_2.module.scss';

const S3_StepTwo_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_3-ambar-2.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S3_StepTwo_2_2'}>
				<div className={styles.text__scena}>
					<p>
						Работа на поле вместе с роботами была непростой, но душевной
						процедурой. Обрабатывая землю и сажая новый урожай, Вы почувствовали
						умиротворение и своеобразную радость, которую мог подарить только
						труд на свежем воздухе.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S3_StepTwo_2;
