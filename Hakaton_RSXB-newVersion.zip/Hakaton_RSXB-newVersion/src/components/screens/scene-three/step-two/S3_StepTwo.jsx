import { Link } from 'react-router-dom';
import styles from './S3_StepTwo.module.scss';

const S3_StepTwo = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_3-zas.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S3_StepTwo_1'}>
				<div className={styles.text__scena}>
					<p>
						Начиная работу на поле, Вы решили начать с диагностики и
						технического обслуживания роботов. Эти машины являются неотъемлемой
						частью Вашей фермы, и важно удостовериться, что они работают без
						сбоев. Проведя проверку,
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S3_StepTwo;
