import { Link } from 'react-router-dom';
import styles from './S5_StepTwo_3_3.module.scss';

const S5_StepTwo_3_3 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_4-vyb3.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S5_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						улучшенные роботы - каждая идея звучала привлекательно. Всё это
						хотелось внедрить как можно скорее, все эти возможности светились на
						горизонте Ваших мечтаний, создавая в Вашем воображении картину
						идеальной фермы будущего.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S5_StepTwo_3_3;
