import { Link } from 'react-router-dom';
import styles from './S5_StepTwo.module.scss';

const S5_StepTwo = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_5-zas.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S5_StepTwo_1'}>
				<div className={styles.text__scena}>
					<p>
						С наступлением вечера, после всего того, что Вы успели сделать за
						день, Вы решили приступить к установке и настройке нового
						оборудования. Это было важное и волнительное занятие. Каждый
						прогресс в технологии добавлял трудностей,
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S5_StepTwo;
