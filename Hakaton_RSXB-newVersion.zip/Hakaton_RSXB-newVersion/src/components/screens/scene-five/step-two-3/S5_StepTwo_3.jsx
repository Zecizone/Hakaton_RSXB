import { Link } from 'react-router-dom';
import styles from './S5_StepTwo_3.module.scss';

const S5_StepTwo_3 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_4-vyb3.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S5_StepTwo_3_3'}>
				<div className={styles.text__scena}>
					<p>
						Вечер был идеальным временем для обдумывания планов по модернизации
						фермы. Под светом звёзд Вы сидели и размышляли об
						усовершенствованиях, которые хотели внести. Новое оборудование,
						более эффективная система полива,
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S5_StepTwo_3;
