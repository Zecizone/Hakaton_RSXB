import { Link } from 'react-router-dom';
import styles from './S5_StepTwo_1.module.scss';

const S5_StepTwo_1 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_5-zas.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S5_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						но также открывал новые возможности для усовершенствования Вашей
						фермы. Вы провели некоторое время, изучая мануалы,
						экспериментировали с настройками, всё, чтобы оборудование работало
						безотказно.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S5_StepTwo_1;
