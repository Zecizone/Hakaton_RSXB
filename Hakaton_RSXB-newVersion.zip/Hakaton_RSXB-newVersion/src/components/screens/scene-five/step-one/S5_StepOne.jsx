import { Link } from 'react-router-dom';
import styles from './S5_StepOne.module.scss';

const S5_StepOne = () => {
	return (
		<div
			className={styles.stepOne}
			style={{ backgroundImage: 'url(../../../../public/scena_5-zas.png)' }}
		>
			{/* <div>
				<Button exit={'../public/exit-no-active.svg'} />
				<Button help={'../public/help-no-active.svg'} />
			</div> */}
			<Link to={'./S5_StepOne_1'}>
				<div className={styles.text__scena}>
					<p>
						Наступил вечер, солнце клонится к горизонту. Вам надо решить, как
						провести этот вечер.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S5_StepOne;
