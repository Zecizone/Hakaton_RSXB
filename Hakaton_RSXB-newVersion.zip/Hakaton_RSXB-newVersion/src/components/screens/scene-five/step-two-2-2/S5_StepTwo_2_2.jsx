import { Link } from 'react-router-dom';
import styles from './S5_StepTwo_2_2.module.scss';

const S5_StepTwo_2_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_5-vyb-2.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'../S5_StepOne'}>
				<div className={styles.text__scena}>
					<p>
						смотрели вечерний закат или просто сидел на пороге своего дома,
						слушая звуки ночи. Такой отдых был важен для восстановления энергии
						и получения новой порции вдохновения для дальнейшей работы на ферме.
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S5_StepTwo_2_2;
