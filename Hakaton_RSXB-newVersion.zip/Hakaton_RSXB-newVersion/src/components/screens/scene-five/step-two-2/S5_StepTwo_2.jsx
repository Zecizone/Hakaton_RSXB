import { Link } from 'react-router-dom';
import styles from './S5_StepTwo_2.module.scss';

const S5_StepTwo_2 = () => {
	return (
		<div
			className={styles.stepTwo}
			style={{ backgroundImage: 'url(../../../../public/scena_5-vyb-2.png)' }}
		>
			{/* <div>
		<Button />
		<Button />
	</div> */}
			<Link to={'./S5_StepTwo_2_2'}>
				<div className={styles.text__scena}>
					<p>
						Когда наступил вечер, Вы решили, что пора дать себе небольшой
						перерыв от работы на ферме и провести вечер в покое, не делая вообще
						ничего. Вы занимались простыми вещами, которые приносили Вам
						удовольствие - читали книгу,
					</p>
				</div>
			</Link>
		</div>
	);
};

export default S5_StepTwo_2;
