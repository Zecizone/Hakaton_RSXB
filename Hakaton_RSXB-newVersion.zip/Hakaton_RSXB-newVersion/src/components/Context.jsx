import React from 'react';

export const TextIntroContext = React.createContext();

export const numContext = React.createContext();

export const colorStateContext = React.createContext();

export const chapterContext = React.createContext();

export const textStepContext = React.createContext();

export const valueNameContext = React.createContext();

export const startContext = React.createContext();
